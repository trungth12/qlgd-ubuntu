- /**
  - * @jsx React.DOM
  - */
"use strict";

var React = require("react");